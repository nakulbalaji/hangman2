#input the word
#it prints the number of letters as undeerscroes
#if the letter input is also found in the word, that letter prints at that index number(location)
# when there are no underscores left the game ends
#only 5 lives
import replit
import time



def clearconsole():
  time.sleep(1)
  replit.clear()
  time.sleep(0.001)

word=str(input("USER 1: Enter a word and give the device to USER 2 : "))
clearconsole()
print(len(word),"letters")
space= (' __')
hiddenword=(len(word))*space
print(hiddenword)

w=0
l=0

while hiddenword.find('__')>-1:
  guess=input("USER 2: Enter a letter (one letter only): ")
  if word.find(guess)==-1:
    print((guess), "is not in the word!")
    l+=1
  elif word.find(guess)>-1:
    print(guess," is in position #", word.find(guess)+1)
    w+=1
    #index of letter in word used to replace letter for underscore 
    # indexnum=word.find(guess)
    # hiddenword[indexnum]=1
    # print(hiddenword)
  if l==6:
    print('You lost! :(')
    print('The word was', word)
    break
  elif w==(len(word)):
    print('YOU WON!')
    print('The word was', word)
    break